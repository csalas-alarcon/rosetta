from controlador import (
    cargar_sistema,
    guardar_datos,
    obtener_input,
    dame_estudiantes_curso,
    dame_cursos_estudiante,
    añadir_estudiante_curso,
    eliminar_estudiante_curso,
    añadir_estudiante,
    eliminar_estudiante,
    añadir_curso,
    eliminar_curso,
    dame_cantidad_estudiantes_cursos
)

# -----------------------------
# Funciones para cada opción
# -----------------------------

def ver_estudiantes_curso():
    id_curso = obtener_input("Ingrese el ID del curso: ")
    año = obtener_input("Ingrese el año: ")
    resultado = dame_estudiantes_curso(id_curso, año)

    if "error" in resultado or "mensaje" in resultado:
        print(resultado.get("error") or resultado.get("mensaje"))
    else:
        for est in resultado:
            print(f"{est['id']}: {est['nombre']} ({est['email']})")

def ver_cursos_estudiante():
    id_estudiante = obtener_input("Ingrese el ID del estudiante: ")
    año = obtener_input("Ingrese el año: ")
    resultado = dame_cursos_estudiante(id_estudiante, año)

    if "error" in resultado or "mensaje" in resultado:
        print(resultado.get("error") or resultado.get("mensaje"))
    else:
        for curso in resultado:
            print(f"{curso['id']}: {curso['nombre']}")

def matricular_estudiante():
    id_estudiante = obtener_input("ID del estudiante: ")
    id_curso = obtener_input("ID del curso: ")
    año = obtener_input("Año: ")
    resultado = añadir_estudiante_curso(id_estudiante, id_curso, año)
    print(resultado.get("mensaje") or resultado.get("error"))

def desmatricular_estudiante():
    id_estudiante = obtener_input("ID del estudiante: ")
    id_curso = obtener_input("ID del curso: ")
    año = obtener_input("Año: ")
    resultado = eliminar_estudiante_curso(id_estudiante, id_curso, año)
    print(resultado.get("mensaje") or resultado.get("error"))

def crear_estudiante():
    id_est = obtener_input("ID del estudiante: ")
    nombre = obtener_input("Nombre: ")
    email = obtener_input("Email: ")
    resultado = añadir_estudiante(id_est, nombre, email)
    print(resultado.get("mensaje") or resultado.get("error"))

def borrar_estudiante():
    id_est = obtener_input("ID del estudiante: ")
    resultado = eliminar_estudiante(id_est)
    print(resultado.get("mensaje") or resultado.get("error"))

def crear_curso():
    id_curso = obtener_input("ID del curso: ")
    nombre = obtener_input("Nombre del curso: ")
    resultado = añadir_curso(id_curso, nombre)
    print(resultado.get("mensaje") or resultado.get("error"))

def borrar_curso():
    id_curso = obtener_input("ID del curso: ")
    resultado = eliminar_curso(id_curso)
    print(resultado.get("mensaje") or resultado.get("error"))

def ver_cantidad_estudiantes_cursos():
    resumen = dame_cantidad_estudiantes_cursos()
    print(f"Total de estudiantes: {resumen['total_estudiantes']}")
    print(f"Total de cursos: {resumen['total_cursos']}")

def salir_y_guardar():
    guardar_datos()
    print("Datos guardados. Saliendo del sistema.")

# -----------------------------
# Menú principal
# -----------------------------

def menu():
    opciones = {
        '1': ver_estudiantes_curso,
        '2': ver_cursos_estudiante,
        '3': matricular_estudiante,
        '4': desmatricular_estudiante,
        '5': crear_estudiante,
        '6': borrar_estudiante,
        '7': crear_curso,
        '8': borrar_curso,
        '9': ver_cantidad_estudiantes_cursos,
        '0': salir_y_guardar
    }

    while True:
        print("\nMenú del sistema:")
        print("1. Ver estudiantes de un curso")
        print("2. Ver cursos de un estudiante")
        print("3. Añadir estudiante a curso")
        print("4. Eliminar estudiante de curso")
        print("5. Añadir estudiante")
        print("6. Eliminar estudiante")
        print("7. Añadir curso")
        print("8. Eliminar curso")
        print("9. Ver cantidad de estudiantes y cursos")
        print("0. Guardar y salir")

        opcion = obtener_input("Seleccione una opción: ")

        if opcion in opciones:
            opciones[opcion]()

            if opcion == '0':
                break
            else:
                obtener_input("Presione Enter para continuar...")
        else:
            print("Opción no válida. Intente de nuevo.")

# -----------------------------
# Función principal
# -----------------------------
def main():
    try:
        cargar_sistema()
    except Exception as e:
        print(f"❌ Error al cargar datos: {e}")
        return

    menu()

if __name__ == "__main__":
    main()
