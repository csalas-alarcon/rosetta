

from flask import Flask, request, jsonify

from Curso import Curso
from Estudiante import Estudiante
from controlador import cargar_sistema, dame_estudiantes_curso, dame_cursos_estudiante, añadir_estudiante_curso, \
    eliminar_estudiante_curso, añadir_estudiante, eliminar_estudiante, añadir_curso, eliminar_curso, \
    dame_cantidad_estudiantes_cursos, guardar_datos,signup, login
from flask_jwt_extended import JWTManager, jwt_required, create_access_token, get_jwt_identity, get_jwt

app = Flask(__name__)
app.config["JWT_SECRET_KEY"] = "super-secret"  #clave secreta para JWT
jwt = JWTManager(app)

cargar_sistema()  # Cargar datos iniciales

# ----------------------------
# ENDPOINTS DE LA API
# ----------------------------



@app.route("/")
def index():
    return "🎓 API REST de Gestión de Matrículas funcionando"

@app.route("/estudiantes", methods=["GET"])  #dame estudiantes (opción que no está en menú)
@jwt_required()
def listar_estudiantes():
    return jsonify([
        {"id": e.id, "nombre": e.nombre, "email": e.email}
        for e in Estudiante.estudiantes_registrados.values()
    ])

@app.route("/cursos", methods=["GET"]) #dame cursos (opción que no está en el menú)
def listar_cursos():
    return jsonify([
        {"id": c.id, "nombre": c.nombre}
        for c in Curso.cursos_registrados.values()
    ])

@app.route("/curso/<curso_id>/estudiantes/<anyo>", methods=["GET"]) #OPC1: dame los estudiantes de un curso
def estudiantes_de_curso(curso_id, anyo):
    resultado = dame_estudiantes_curso(curso_id, anyo)

    if "error" in resultado:
        return jsonify(resultado), 404

    return jsonify(resultado), 200



@app.route("/estudiante/<estudiante_id>/cursos/<anyo>", methods=["GET"]) #OPC2: dame los cursos de un estudiante
def cursos_de_estudiante(estudiante_id, anyo):
    resultado = dame_cursos_estudiante(estudiante_id, anyo)
    if "error" in resultado:
        return jsonify(resultado), 404

    return jsonify(resultado), 200

@app.route("/matricular", methods=["POST"]) #OPC3: Añadir estudiante a curso. ESPERO JSON
def add_student_to_course():
    if not request.is_json:
        return jsonify({"error": "Request must be application/json"}), 415
    datos = request.get_json()

    student_id = datos.get("student_id")
    course_id = datos.get("course_id")
    year = datos.get("year")

    if not all([student_id, course_id, year]):
        return jsonify({"error": "Missing data: student_id, course_id, and year are required."}), 400

    resultado = añadir_estudiante_curso(student_id, course_id, year)

    if "error" in resultado:
        return jsonify(resultado), 404
    else:
        guardar_datos()
        return jsonify(resultado), 201

"""
opción 3 pero trabajando con keywords en lugar de json (transpa 37):

@app.route("/matricular/<string:student_id>/<string:course_id>/<string:year>", methods=["POST"]) #OPC3: Añadir estudiante a curso
def add_student_to_course():
    student_id = request.args.get("student_id")
    course_id = request.args.get("course_id")
    year = request.args.get("year")
    if not all([student_id, course_id, year]):
        return jsonify({"error": "Missing data: student_id, course_id, and year are required."}), 400
    resultado = añadir_estudiante_curso(student_id, course_id, year)
    if "error" in resultado:
        return jsonify(resultado), 404
    else: 
        guardar_datos()
        return jsonify(resultado), 201
"""


@app.route("/desmatricular", methods=["DELETE"]) #OPC4: Eliminar estudiante de curso
def delete_student_from_course():
    datos = request.get_json()

    student_id = datos.get("student_id")
    course_id = datos.get("course_id")
    year = datos.get("year")

    if not all([student_id, course_id, year]):
        return jsonify({"error": "Missing data: student_id, course_id and year are required."}), 400

    resultado = eliminar_estudiante_curso(student_id, course_id, year)

    if "error" in resultado:
        return jsonify(resultado), 404
    else:
        guardar_datos()
        return jsonify(resultado), 200

@app.route("/estudiante", methods=["POST"])  #opción 5: añadir estudiante
def add_student():
    datos = request.get_json()
    student_id = datos.get("id")
    name = datos.get("name")
    email = datos.get("email")

    if not all([student_id, name, email]):
        return jsonify({"error": "Missing fields: id, name, email are required"}), 400

    resultado = añadir_estudiante(student_id, name, email)

    if "error" in resultado:
        return jsonify(resultado), 400
    else:
        guardar_datos()
        return jsonify(resultado), 201


@app.route("/estudiante", methods=["DELETE"])  #opción 6: eliminar estudiante
def delete_student():
    datos = request.get_json()
    student_id = datos.get("id")

    if not student_id:
        return jsonify({"error": "Missing field: id"}), 400

    resultado = eliminar_estudiante(student_id)

    if "error" in resultado:
        return jsonify(resultado), 404
    else:
        guardar_datos()
        return jsonify(resultado), 200

@app.route("/curso", methods=["POST"]) #opción 7: añadir curso
def add_course():
    datos = request.get_json()
    course_id = datos.get("id")
    name = datos.get("name")

    if not course_id or not name:
        return jsonify({"error": "Missing fields: id and name are required"}), 400

    resultado = añadir_curso(course_id, name)

    if "error" in resultado:
        return jsonify(resultado), 400
    else:
        guardar_datos()
        return jsonify(resultado), 201


@app.route("/curso", methods=["DELETE"]) #opción 8: eliminar curso
def delete_course():
    datos = request.get_json()
    course_id = datos.get("id")

    if not course_id:
        return jsonify({"error": "Missing field: id"}), 400

    resultado = eliminar_curso(course_id)

    if "error" in resultado:
        return jsonify(resultado), 404

    else:
        guardar_datos()
        return jsonify(resultado), 200


@app.route("/resumen", methods=["GET"])  #opción 9: resumen datos
def obtener_resumen_estudiantes_cursos():
    resumen = dame_cantidad_estudiantes_cursos()
    return jsonify(resumen), 200


@app.route("/signup", methods=["POST"])
def endpoint_signup():
    datos = request.get_json()
    user = datos.get("user")
    passwd = datos.get("passwd")

    resultado = signup(user, passwd)

    if "error" in resultado:
        if "ya existe" in resultado["error"]:
            return jsonify(resultado), 409
        return jsonify(resultado), 400

    return jsonify(resultado), 201



@app.route("/login", methods=["GET"])
def endpoint_login():
    user = request.args.get("user")
    passwd = request.args.get("passwd")

    resultado = login(user, passwd)

    if "error" in resultado:
        if resultado["error"] == "No hay usuarios registrados":
            return jsonify(resultado), 404
        else:
            return jsonify(resultado), 401

    # Login correcto → generar token
    access_token = create_access_token(identity=user)
    return jsonify({"access_token": access_token}), 200

# ----------------------------
# EJECUCIÓN
# ----------------------------
if __name__ == "__main__":
    app.run(debug=True, port=5050)