import re
import csv
import requests

# -----------------------------
# Clase Estudiante
# -----------------------------
class Estudiante:
    total_estudiantes = 0
    # Diccionario para acceder a estudiantes por su id
    estudiantes_registrados = {}

    def __init__(self, id, nombre, email):
        self.id = id
        self.nombre = nombre
        self.email = email
        # Diccionario: clave = año, valor = lista de cursos en ese año
        self.cursos = {}
        Estudiante.total_estudiantes += 1
        Estudiante.estudiantes_registrados[id] = self
        print(requests.get)

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value
    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, value):
        self._nombre = value
    @property
    def email(self):
        return self._email

    @email.setter
    def email(self, value):
        if not self.validar_email(value):
            raise ValueError("Email inválido")
        self._email = value

    @staticmethod
    def factory_crear_estudiante(id, nombre, email):
        if not Estudiante.validar_email(email):
            raise ValueError("Email inválido")
        return Estudiante(id, nombre, email)
    @classmethod
    def cargar_estudiantes(cls,archivo):
        try:
            with open(archivo, newline='', encoding='utf-8') as csvfile:
                lector = csv.DictReader(csvfile)
                for fila in lector:
                    id = fila['id']
                    nombre = fila['nombre']
                    email = fila['email']
                    if not Estudiante.validar_email(email):
                        print(f"Email inválido para el estudiante {nombre}: {email}")
                    Estudiante(id, nombre, email)
        except Exception as e:
            print(f"Error al cargar estudiantes: {e}")

    @classmethod
    def guardar_estudiantes(cls, archivo):
        try:
            with open(archivo, mode='w', newline='', encoding='utf-8') as csvfile:
                campos = ['id', 'nombre', 'email']
                writer = csv.DictWriter(csvfile, fieldnames=campos)
                writer.writeheader()
                for est in cls.estudiantes_registrados.values():
                    writer.writerow({'id': est.id, 'nombre': est.nombre, 'email': est.email})
        except Exception as e:
            print(f"Error al guardar estudiantes en {archivo}: {e}")
    def __repr__(self):
        return f"Estudiante({self.id}, {self.nombre}, {self.email})"

    def __str__(self):
        return f"ID: {self.id}\nNombre: {self.nombre}\nEmail:({self.email}\nCursos:{self.cursos}"

    @staticmethod
    def validar_email(email):
        patron = r"^[\w\.-]+@[\w\.-]+\.\w+$"
        return re.match(patron, email) is not None

    @classmethod
    def contar_estudiantes(cls):
        return cls.total_estudiantes

    def agregar_curso(self, curso, año):
        # Agregar al diccionario del estudiante
        if año not in self.cursos:
            self.cursos[año] = []
        if curso not in self.cursos[año]:
            self.cursos[año].append(curso)


    def eliminar_curso(self, curso, año):
        if año in self.cursos and curso in self.cursos[año]:
            self.cursos[año].remove(curso)

if __name__=="__main__":
    try:
        e=Estudiante.factory_crear_estudiante("e020","Cris","ccachero@")
        print(Estudiante.total_estudiantes)
    except ValueError as e:
        print("Error:",e)

    try:
        e=Estudiante.factory_crear_estudiante("e020","Cris","ccachero@dlsi.ua.es")
        print(Estudiante.total_estudiantes)
        e.agregar_curso("Python",2024)
        print(e)
    except Exception as e:
        print("Error:",e)