import requests

BASE_URL = "http://127.0.0.1:5050"
TOKEN = None  # Guardará el token JWT tras login

def get_headers(auth_required=False):
    headers = {"Content-Type": "application/json"}
    if auth_required and TOKEN:
        headers["Authorization"] = f"Bearer {TOKEN}"
    return headers

def menu():
    print("\n🎓 Menú de opciones:")
    print("1. Login")
    print("2. Signup")
    print("3. Listar estudiantes (requiere login)")
    print("4. Listar cursos")
    print("5. Ver estudiantes de un curso y año")
    print("6. Ver cursos de un estudiante y año")
    print("7. Matricular estudiante en curso")
    print("8. Desmatricular estudiante de curso")
    print("9. Añadir estudiante")
    print("10. Eliminar estudiante")
    print("11. Añadir curso")
    print("12. Eliminar curso")
    print("13. Ver resumen estudiantes/cursos")
    print("0. Salir")

def login():
    global TOKEN
    user = input("Usuario: ")
    passwd = input("Contraseña: ")
    r = requests.get(f"{BASE_URL}/login", params={"user": user, "passwd": passwd})
    print("Respuesta:", r.status_code, r.json())
    if r.status_code == 200:
        TOKEN = r.json()["access_token"]

def signup():
    user = input("Usuario nuevo: ")
    passwd = input("Contraseña: ")
    r = requests.post(f"{BASE_URL}/signup", json={"user": user, "passwd": passwd})
    print("Respuesta:", r.status_code, r.json())

def listar_estudiantes():
    r = requests.get(f"{BASE_URL}/estudiantes", headers=get_headers(auth_required=True))
    print("Respuesta:", r.status_code, r.json())

def listar_cursos():
    r = requests.get(f"{BASE_URL}/cursos")
    print("Respuesta:", r.status_code, r.json())

def estudiantes_de_curso():
    curso_id = input("ID del curso: ")
    anyo = input("Año: ")
    r = requests.get(f"{BASE_URL}/curso/{curso_id}/estudiantes/{anyo}")
    print("Respuesta:", r.status_code, r.json())

def cursos_de_estudiante():
    estudiante_id = input("ID del estudiante: ")
    anyo = input("Año: ")
    r = requests.get(f"{BASE_URL}/estudiante/{estudiante_id}/cursos/{anyo}")
    print("Respuesta:", r.status_code, r.json())

def matricular_estudiante():
    student_id = input("ID estudiante: ")
    course_id = input("ID curso: ")
    year = input("Año: ")
    r = requests.post(f"{BASE_URL}/matricular", json={
        "student_id": student_id,
        "course_id": course_id,
        "year": year
    })
    print("Respuesta:", r.status_code, r.json())

def desmatricular_estudiante():
    student_id = input("ID estudiante: ")
    course_id = input("ID curso: ")
    year = input("Año: ")
    r = requests.delete(f"{BASE_URL}/desmatricular", json={
        "student_id": student_id,
        "course_id": course_id,
        "year": year
    })
    print("Respuesta:", r.status_code, r.json())

def añadir_estudiante():
    student_id = input("ID nuevo estudiante: ")
    name = input("Nombre: ")
    email = input("Email: ")
    r = requests.post(f"{BASE_URL}/estudiante", json={
        "id": student_id,
        "name": name,
        "email": email
    })
    print("Respuesta:", r.status_code, r.json())

def eliminar_estudiante():
    student_id = input("ID estudiante a eliminar: ")
    r = requests.delete(f"{BASE_URL}/estudiante", json={"id": student_id})
    print("Respuesta:", r.status_code, r.json())

def añadir_curso():
    course_id = input("ID nuevo curso: ")
    name = input("Nombre del curso: ")
    r = requests.post(f"{BASE_URL}/curso", json={
        "id": course_id,
        "name": name
    })
    print("Respuesta:", r.status_code, r.json())

def eliminar_curso():
    course_id = input("ID del curso a eliminar: ")
    r = requests.delete(f"{BASE_URL}/curso", json={"id": course_id})
    print("Respuesta:", r.status_code, r.json())

def resumen():
    r = requests.get(f"{BASE_URL}/resumen")
    print("Respuesta:", r.status_code, r.json())

# ----------------------------
# Bucle principal
# ----------------------------
acciones = {
    "1": login,
    "2": signup,
    "3": listar_estudiantes,
    "4": listar_cursos,
    "5": estudiantes_de_curso,
    "6": cursos_de_estudiante,
    "7": matricular_estudiante,
    "8": desmatricular_estudiante,
    "9": añadir_estudiante,
    "10": eliminar_estudiante,
    "11": añadir_curso,
    "12": eliminar_curso,
    "13": resumen,
}

if __name__ == "__main__":
    while True:
        menu()
        opcion = input("Elige una opción: ")
        if opcion == "0":
            print("👋 Saliendo...")
            break
        accion = acciones.get(opcion)
        if accion:
            accion()
        else:
            print("Opción no válida.")
