import csv
from Curso import Curso
from Estudiante import Estudiante



def cargar_matriculas(archivo):
    try:
        with open(archivo, newline='', encoding='utf-8') as csvfile:
            lector = csv.DictReader(csvfile)
            for fila in lector:
                id_estudiante = fila['id_estudiante']
                id_curso = fila['id_curso']
                año = fila['año']
                estudiante = Estudiante.estudiantes_registrados.get(id_estudiante)
                curso = Curso.cursos_registrados.get(id_curso)
                if estudiante and curso:
                    # Usamos la sobrecarga del operador += para añadir la matrícula
                    curso += (estudiante, año)
                else:
                    print(f"Error en matrícula: {fila}")
    except Exception as e:
        print(f"Error al cargar matrículas: {e}")

def guardar_matriculas(archivo):
    try:
        with open(archivo, mode='w', newline='', encoding='utf-8') as csvfile:
            campos = ['id_estudiante', 'id_curso', 'año']
            writer = csv.DictWriter(csvfile, fieldnames=campos)
            writer.writeheader()
            for curso in Curso.cursos_registrados.values():
                for año, estudiantes in curso.estudiantes.items():
                    for estudiante in estudiantes:
                        writer.writerow({
                            'id_estudiante': estudiante.id,
                            'id_curso': curso.id,
                            'año': año
                        })
    except Exception as e:
        print(f"Error al guardar matrículas en {archivo}: {e}")
