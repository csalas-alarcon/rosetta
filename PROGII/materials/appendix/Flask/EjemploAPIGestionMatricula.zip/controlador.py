import csv
from Estudiante import Estudiante
from Curso import Curso
from GestorMatriculas import cargar_matriculas, guardar_matriculas
import hashlib
import os


def cargar_sistema():
    Estudiante.cargar_estudiantes("estudiantes.csv")
    Curso.cargar_cursos("cursos.csv")
    cargar_matriculas("matriculas.csv")

    print("Sistema cargado con éxito.")

def obtener_input(mensaje):
    return input(mensaje)



def dame_estudiantes_curso(id_curso, año):  #OPC1: dame los estudiantes de un curso
    curso = Curso.cursos_registrados.get(id_curso)
    if not curso:
        return {"error": "Curso no encontrado."}

    est_list = curso.estudiantes.get(año, [])
    if not est_list:
        return {"mensaje": "No hay estudiantes matriculados en ese año para este curso."}

    return [{"id": est.id, "nombre": est.nombre, "email": est.email} for est in est_list]


def dame_cursos_estudiante(id_estudiante, anyo): #OPC2: dame los cursos de un estudiante
    estudiante = Estudiante.estudiantes_registrados.get(id_estudiante)
    if not estudiante:
        return {"error": "Estudiante no encontrado"}

    cursos_list = estudiante.cursos.get(anyo, [])
    if not cursos_list:
        return {"mensaje": "El estudiante no está matriculado en ningún curso ese año"}

    return [
        {"id": curso.id, "nombre": curso.nombre}
        for curso in cursos_list
        ]



def añadir_estudiante_curso(id_estudiante, id_curso, año):  #matricular: opción 3
    """
    Se podría mejorar comprobando que no inteto añadir un etudiante que ya está, aunque ahora mismo se sobreescribe
    y no da problemas.

    """
    estudiante = Estudiante.estudiantes_registrados.get(id_estudiante)
    curso = Curso.cursos_registrados.get(id_curso)

    if not estudiante:
        return {"error": "Estudiante no encontrado"}
    if not curso:
        return {"error": "Curso no encontrado"}

    curso.agregar_estudiante(estudiante,año)
    estudiante.agregar_curso(curso, año)
    return {"mensaje": "Estudiante añadido al curso correctamente"}


def eliminar_estudiante_curso(id_estudiante,id_curso,anyo): #eliminar estudiante de curso: opción 4
    estudiante = Estudiante.estudiantes_registrados.get(id_estudiante)
    curso = Curso.cursos_registrados.get(id_curso)
    if not estudiante:
        return {"error": "Estudiante no encontrado"}
    if not curso:
        return {"error": "Curso no encontrado"}

    estudiante.eliminar_curso(curso, anyo)
    curso.eliminar_estudiante(estudiante, anyo)
    return {"mensaje": "estudiante eliminado del curso correctamente"}

def añadir_estudiante(id, nombre, email):  #opción 5
    if id in Estudiante.estudiantes_registrados:
        return {"error": "El estudiante ya existe"}
    if not id or not nombre or not email:
        return {"error": "ID, nombre y email del estudiante son obligatorios"}
    if not Estudiante.validar_email(email):
        return {"error": "Email inválido"}

    Estudiante(id, nombre, email)
    return {"mensaje": "Estudiante añadido correctamente"}


def eliminar_estudiante(id):
    estudiante = Estudiante.estudiantes_registrados.pop(id, None)
    if estudiante:
        for año, cursos_list in estudiante.cursos.items():
            for curso in cursos_list:
                if año in curso.estudiantes and estudiante in curso.estudiantes[año]:
                    curso.estudiantes[año].remove(estudiante)
        return {"mensaje": "estudiante eliminado correctamente"}
    else:
        return {"error": "estudiante no encontrado"}


def añadir_curso(id, nombre):
    if id in Curso.cursos_registrados:
        return {"error": "El curso ya existe"}

    if not id or not nombre:
        return {"error": "ID y nombre del curso son obligatorios"}

    Curso(id, nombre)
    return {"mensaje": "Curso añadido correctamente"}


def eliminar_curso(id):
    curso = Curso.cursos_registrados.pop(id, None)
    if curso:
        for año, estudiantes_list in curso.estudiantes.items():
            for estudiante in estudiantes_list:
                if año in estudiante.cursos and curso in estudiante.cursos[año]:
                    estudiante.cursos[año].remove(curso)
        return {"mensaje": "Curso eliminado correctamente"}
    else:
        return {"error": "Curso no encontrado"}



def dame_cantidad_estudiantes_cursos(): #opción 9
    return {
        "total_estudiantes": Estudiante.contar_estudiantes(),
        "total_cursos": Curso.contar_cursos()
    }


def guardar_datos():
    try:
        Estudiante.guardar_estudiantes("estudiantes.csv")
        print("✅ Estudiantes guardados correctamente.")
    except Exception as e:
        print(f"❌ Error al guardar estudiantes: {e}")

    try:
        Curso.guardar_cursos("cursos.csv")
        print("✅ Cursos guardados correctamente.")
    except Exception as e:
        print(f"❌ Error al guardar cursos: {e}")

    try:
        guardar_matriculas("matriculas.csv")
        print("✅ Matrículas guardadas correctamente.")
    except Exception as e:
        print(f"❌ Error al guardar matrículas: {e}")




ADMIN_FILE = "administradores.csv"

def signup(user, passwd):
    if not user or not passwd:
        return {"error": "Faltan parámetros: user y passwd"}

    # Crear archivo si no existe
    if not os.path.exists(ADMIN_FILE):
        with open(ADMIN_FILE, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["user", "passwd_hash"])

    # Verificar si el usuario ya existe
    with open(ADMIN_FILE, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["user"] == user:
                return {"error": "El usuario ya existe"}

    # Hashear la contraseña
    hash_pass = hashlib.sha256(passwd.encode()).hexdigest()

    # Guardar usuario
    with open(ADMIN_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([user, hash_pass])

    return {"mensaje": "Usuario registrado correctamente"}


def login(user, passwd):
    if not os.path.exists(ADMIN_FILE):
        return {"error": "No hay usuarios registrados"}

    passwd_hash = hashlib.sha256(passwd.encode()).hexdigest()

    with open(ADMIN_FILE, "r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if row["user"] == user and row["passwd_hash"] == passwd_hash:
                return {"ok": True}

    return {"error": "Usuario o contraseña incorrectos"}