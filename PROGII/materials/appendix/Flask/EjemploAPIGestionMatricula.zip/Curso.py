import re
import csv
class Curso:
    total_cursos = 0
    # Diccionario para acceder a cursos por su id
    cursos_registrados = {}

    def __init__(self, id, nombre):
        self.id = id
        self.nombre = nombre
        # Diccionario: clave = año, valor = lista de estudiantes matriculados en ese año
        self.estudiantes = {}
        Curso.total_cursos += 1
        Curso.cursos_registrados[id] = self

    @classmethod
    def cargar_cursos(cls,archivo):
        try:
            with open(archivo, newline='', encoding='utf-8') as csvfile:
                lector = csv.DictReader(csvfile)
                for fila in lector:
                    id = fila['id']
                    nombre = fila['nombre']
                    Curso(id, nombre)
        except Exception as e:
            print(f"Error al cargar cursos: {e}")

    @classmethod
    def guardar_cursos(cls, archivo):
        try:
            with open(archivo, mode='w', newline='', encoding='utf-8') as csvfile:
                campos = ['id', 'nombre']
                writer = csv.DictWriter(csvfile, fieldnames=campos)
                writer.writeheader()
                for curso in cls.cursos_registrados.values():
                    writer.writerow({'id': curso.id, 'nombre': curso.nombre})
        except Exception as e:
            print(f"Error al guardar cursos en {archivo}: {e}")

    @property
    def id(self):
        return self._id

    @id.setter
    def id(self, value):
        self._id = value

    @property
    def nombre(self):
        return self._nombre

    @nombre.setter
    def nombre(self, value):
        self._nombre = value
    def __repr__(self):
        return f"Curso({self.id}, {self.nombre})"

    def __str__(self):
        return self.nombre

    # Método auxiliar para agregar estudiante
    def agregar_estudiante(self, estudiante, año):
        # Agregar al diccionario del curso
        if año not in self.estudiantes:
            self.estudiantes[año] = []
        if estudiante not in self.estudiantes[año]:
            self.estudiantes[año].append(estudiante)


    # Método auxiliar para eliminar estudiante
    def eliminar_estudiante(self, estudiante, año):
        if año in self.estudiantes and estudiante in self.estudiantes[año]:
            self.estudiantes[año].remove(estudiante)


    # Sobrecarga del operador + (no in-place)
    def __add__(self, datos):
        # datos es una tupla (estudiante, año)
        estudiante, año = datos
        self.agregar_estudiante(estudiante, año)
        return self

    # Sobrecarga del operador - (no in-place)
    def __sub__(self, datos):
        estudiante, año = datos
        self.eliminar_estudiante(estudiante, año)
        return self

    # Sobrecarga del operador += (in-place)
    def __iadd__(self, datos):
        estudiante, año = datos
        self.agregar_estudiante(estudiante, año)
        return self

    # Sobrecarga del operador -= (in-place)
    def __isub__(self, datos):
        estudiante, año = datos
        self.eliminar_estudiante(estudiante, año)
        return self

    @classmethod
    def contar_cursos(cls):
        return cls.total_cursos

if __name__=="__main__":
    pass