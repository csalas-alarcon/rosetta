# 🎓 Sistema de Gestión de Matrículas

Este proyecto es una aplicación modular en Python para gestionar la matrícula de estudiantes en cursos, con soporte para interacción por consola y una API REST protegida con JWT.

---

## 🧱 Estructura del Proyecto

```bash
├── Estudiante.py             # Clase Estudiante (con persistencia propia)
├── Curso.py                  # Clase Curso (con persistencia propia)
├── GestorMatriculas.py       # Funciones para gestionar matrículas
├── controlador.py            # Lógica de negocio: servicios del sistema
├── main.py                   # Interfaz por consola (menú interactivo)
├── api.py                    # API REST con Flask + JWT
├── estudiantes.csv           # Datos de estudiantes
├── cursos.csv                # Datos de cursos
├── matriculas.csv            # Datos de matrículas
├── administradores.csv       # Administradores registrados (login/signup)
└── README.md                 # Documentación
```

---

## ▶️ Modo Consola

Ejecuta:

```bash
python main.py
```

Y podrás:

- Ver estudiantes por curso y año
- Ver cursos por estudiante y año
- Añadir/eliminar estudiantes y cursos
- Matricular/desmatricular estudiantes
- Guardar los datos en archivos CSV

---

## 🌐 API REST

Levanta el servidor:

```bash
python api.py
```

Accede a endpoints como:

- `POST /signup` → Registrar nuevo administrador
- `GET /login?user=...&passwd=...` → Obtener token JWT
- `GET /estudiantes` → Listar estudiantes (requiere JWT)
- `POST /matricular` → Matricular estudiante en curso

**Token JWT** requerido en cabecera:

```
Authorization: Bearer <token>
```

---

## 🔐 Seguridad con JWT

Los endpoints protegidos usan `@jwt_required()` para garantizar que solo usuarios autenticados puedan acceder.

Puedes gestionar usuarios administradores desde la API (no desde consola por ahora).

---

## 📦 Diagrama de paquetes (Mermaid)

```mermaid
graph TD

Estudiante[Estudiante.py]
Curso[Curso.py]
GestorMatriculas[GestorMatriculas.py]
Controlador[controlador.py]
Main[main.py]
API[api.py]
JWT[Flask-JWT-Extended]

Estudiante -->|define y persiste| ClaseEstudiante[Clase: Estudiante]
Curso -->|define y persiste| ClaseCurso[Clase: Curso]

Controlador --> Estudiante
Controlador --> Curso
Controlador --> GestorMatriculas

Main --> Controlador
API --> Controlador
API --> JWT
JWT -->|protege| API

Controlador -->|usa métodos de clase| ClaseEstudiante
Controlador -->|usa métodos de clase| ClaseCurso
Controlador -->|usa funciones| GestorMatriculas

subgraph Entidades
    Estudiante
    Curso
end

subgraph Persistencia
    GestorMatriculas
end

subgraph Interfaces
    Main
    API
end
```
---

## 🧩 Diagrama de clases (Mermaid)

```mermaid
classDiagram

class Estudiante {
    - id: str
    - nombre: str
    - email: str
    - cursos: dict[str, list[Curso]]
    + __repr__()
    + __str__()
    + agregar_curso(curso, año)
    + eliminar_curso(curso, año)
    + static validar_email(email): bool
    + class contar_estudiantes(): int
    + class cargar_estudiantes(fichero)
    + class guardar_estudiantes(fichero)
    + class estudiantes_registrados: dict[str, Estudiante]
}

class Curso {
    - id: str
    - nombre: str
    - estudiantes: dict[str, list[Estudiante]]
    + __repr__()
    + __str__()
    + agregar_estudiante(est, año)
    + eliminar_estudiante(est, año)
    + class contar_cursos(): int
    + class cargar_cursos(fichero)
    + class guardar_cursos(fichero)
    + class cursos_registrados: dict[str, Curso]
}

Estudiante "1" --> "many" Curso : cursos[año]
Curso "1" --> "many" Estudiante : estudiantes[año]
```

---



## 🚀 Próximas mejoras

- Gestión de administradores desde consola
- Logs de actividad
- Exportación a JSON o base de datos
- Interfaz web

---

## 📬 Contacto

Proyecto educativo desarrollado para prácticas de programación y arquitectura de software.  
Para consultas, escribe a: **tu.email@ejemplo.com**

---
